<?php echo $__env->make('adpanel.rectra.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('adpanel.rectra.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('adpanel.rectra.sidemenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="content-page">

    <!-- Start content -->
    <div class="content">
        <div class="">
            <div class="page-header-title">
                <h4 class="page-title">Add Faculty</h4></div>
        </div>
       <div class="page-content-wrapper">
            <div class="container-fluid">
                <?php if(session()->has('success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session()->get('success')); ?>

                </div>
                <?php endif; ?>
                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger" role="alert">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                <?php echo $__env->yieldContent('content'); ?>
            </div>
            <!-- container -->
        </div>
        <!-- Page content Wrapper -->
    </div>
</div>

<?php echo $__env->make('adpanel.rectra.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('javascript'); ?>
</body>
</html>
<?php /**PATH D:\laravel\KazirangaUniversity\resources\views/adpanel/rectra/layout.blade.php ENDPATH**/ ?>